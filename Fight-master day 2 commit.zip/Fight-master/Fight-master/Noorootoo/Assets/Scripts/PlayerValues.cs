﻿using UnityEngine;
using System.Collections;

public class PlayerValues : MonoBehaviour {

	private const float MAX_HEALTH = 100;

	public float m_Health;
	public float m_Damage;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}


    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "LeftHand" || col.gameObject.tag == "RightHand")
        {
            m_Health = m_Health - 20;
        }

        if (col.gameObject.tag == "LeftFoot" || col.gameObject.tag == "RightFoot")
        {
            m_Health = m_Health - 10;
        }

    }
}
